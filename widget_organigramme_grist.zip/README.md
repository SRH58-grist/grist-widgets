# Widget organigramme pour Grist

## Ce que fait cette version
- organigramme hiérarchique à partir de `Supérieur hiérarchique`
- filtre par direction
- filtre par service
- mode nominatif / fonctionnel
- niveaux de détail : épuré / standard / détaillé
- affichage ou masquage des postes vacants
- conservation automatique des postes parents lorsqu'on filtre un service
- impression / export PDF via le navigateur
- les postes cochés `Poste d'encadrement ?` sont visuellement distingués

## Colonnes à mapper dans Grist

Obligatoires :
- Intitulé du poste -> `Intitulé du poste`
- Supérieur hiérarchique -> `Supérieur hiérarchique`

Très recommandées :
- Direction -> `DIRECTION`
- Service (libellé) -> une colonne texte contenant le nom du service
- Occupant / nom complet -> une colonne texte contenant le nom de l'agent
- Catégorie -> `Catégorie`
- Statut du poste -> `Statut poste`
- ID du poste -> `ID_Poste`
- Poste d'encadrement ? -> ta nouvelle checkbox

Optionnelles :
- Quotité
- Ordre organigramme
- Afficher dans l'organigramme ?

### Si SERVICE est une référence
Crée dans `Postes` une colonne formule texte, par exemple `Service_org` :
    return $SERVICE.SERVICE

Puis mappe `Service (libellé)` vers `Service_org`.

### Pour le nominatif
Le widget attend idéalement une colonne texte dans `Postes`, par exemple `Occupant_org`.
Si tu n'as pas encore cette colonne, le mode fonctionnel marche déjà.
On peut ensuite relier automatiquement ta table Agents à Postes.

## Mise en ligne avec GitHub Pages
1. Crée un dépôt GitHub, par exemple `grist-organigramme`.
2. Ajoute le fichier `index.html` à la racine.
3. Dans GitHub : Settings > Pages.
4. Dans "Build and deployment", choisis "Deploy from a branch".
5. Branche : `main`, dossier : `/ (root)`, puis Save.
6. GitHub te donnera une URL publique en HTTPS finissant généralement par `/grist-organigramme/`.

## Ajout dans Grist
1. Dans la page voulue : Ajouter nouveau > Ajouter un widget à la page.
2. Choisir `Personnalisé`.
3. Pour les données, choisir la table `Postes`.
4. Ajouter le widget.
5. Menu ⋮ du widget > Options du widget.
6. Coller l'URL GitHub Pages.
7. Accorder `Lire la table sélectionnée`.
8. Dans le panneau de droite, mapper les colonnes demandées.
9. Agrandir le widget : l'organigramme s'adapte automatiquement.

Important : ne donne jamais "Accès complet au document" à une URL que tu ne contrôles pas. Cette version n'en a pas besoin.
